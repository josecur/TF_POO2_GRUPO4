package Controller.DenunciaControllers;

import Interfaces.Controller;
import Interfaces.Listener;
import Model.FlujoDenunciaModel;
import Util.TxTUtil;
import View.DenunciaViews.TerminosYCondicionesView;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TerminosYCondicionesController extends Controller implements Listener {
    private TerminosYCondicionesView terminosYCondicionesView;
    private FlujoDenunciaModel flujoDenunciaModel;


    public TerminosYCondicionesController(FlujoDenunciaModel flujoDenunciaModel) {
        this.flujoDenunciaModel = flujoDenunciaModel;
    }

    @Override
    public void run() {
        terminosYCondicionesView = new TerminosYCondicionesView(this);

    }

    public String leerDocumento(){

        return TxTUtil.leerTxt();

    }

    public void nextView(){
        changeView("Datos Personales");
    }

    public void previousView(){
        flujoDenunciaModel.limpiar();
        changeView("Pantalla Principal");
    }

    public void limpiar(){
        terminosYCondicionesView.clear_fields();
    }


    public TerminosYCondicionesView getView() {
        return terminosYCondicionesView;
    }

    @Override
    public void update(String evento) {
        if(evento.equals("RESET")){
            limpiar();
        }
    }
}
