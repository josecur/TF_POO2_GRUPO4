package Controller.DenunciaControllers.TiposDenuncias;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import View.DenunciaViews.TiposDenuncias.DomesticaView;

public class DomesticaController implements ControllerForm {
    private DomesticaView domesticaView;
    private DenunciaFormController denunciaFormController;

    @Override
    public void run() {
        domesticaView = new DomesticaView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo() {

        return new DetallesDenunciaBuilder()
                .victima(domesticaView.getVictima())
                .agresor(domesticaView.getAgresor())
                .relacionAgresor(domesticaView.getRelacionAgresor())

                .testigos(domesticaView.getTestigos())
                .frecuencia(domesticaView.getFrecuencia())
                .heridas(domesticaView.getHeridas())
                .gravedadHeridas(domesticaView.getGravedadHeridas())
                .hospitalizacion(domesticaView.getHospitalizacion())
                .menoresInvolucrados(domesticaView.getMenoresInvolucrados())
                .descripcion(domesticaView.getDescripcion());
    }

    public DomesticaView getView(){
        return  domesticaView;
    }

    public void reset_fields(){
        domesticaView.reset();
    }
}
