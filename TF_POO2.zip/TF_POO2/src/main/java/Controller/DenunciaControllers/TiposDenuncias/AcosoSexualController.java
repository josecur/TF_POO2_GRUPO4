package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import View.DenunciaViews.TiposDenuncias.AcosoSexualView;

public class AcosoSexualController implements ControllerForm {
    private AcosoSexualView acosoSexualView;

    @Override
    public void run() {
        acosoSexualView = new AcosoSexualView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo() {


        return new DetallesDenunciaBuilder()
                .victima(acosoSexualView.getVictima())
                .agresor(acosoSexualView.getAgresor())
                .relacionAgresor(acosoSexualView.getRelacionAgresor())

                .testigos(acosoSexualView.getTestigos())
                .frecuencia(acosoSexualView.getFrecuencia())
                .descripcion(acosoSexualView.getDescripcion());
    }

    public AcosoSexualView getView(){
        return acosoSexualView;
    }

    public void reset_fields(){
        acosoSexualView.reset();
    }
}
