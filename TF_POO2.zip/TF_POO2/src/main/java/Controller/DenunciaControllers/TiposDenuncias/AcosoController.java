package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import View.DenunciaViews.TiposDenuncias.AcosoView;

public class AcosoController implements ControllerForm {
    AcosoView acosoView;

    @Override
    public void run() {
        acosoView = new AcosoView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo(){

        return new DetallesDenunciaBuilder()
                .victima(acosoView.getVictima())
                .agresor(acosoView.getAgresor())
                .relacionAgresor(acosoView.getRelacionAgresor())

                .testigos(acosoView.getTestigos())
                .frecuencia(acosoView.getFrecuencia())
                .medio(acosoView.getMedio())
                .descripcion(acosoView.getDescripcion());
    }

    public AcosoView getView(){
        return acosoView;
    }
    public void reset_fields(){
        acosoView.reset();
    }
}
