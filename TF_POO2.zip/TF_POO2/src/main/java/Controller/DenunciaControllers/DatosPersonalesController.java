package Controller.DenunciaControllers;

import Interfaces.Controller;
import Interfaces.Listener;
import Interfaces.TipoDocumento;
import Model.DatosPersonalesModel;
import Model.FlujoDenunciaModel;
import Util.Denuncia.DatosPersonales;
import View.DenunciaViews.DatosPersonalesView;


public class DatosPersonalesController extends Controller implements Listener {
    private DatosPersonalesView datosPersonalsView;
    private DatosPersonalesModel datosPersonalesModel = new DatosPersonalesModel();
    private FlujoDenunciaModel flujoDenuncia;

    public DatosPersonalesController(FlujoDenunciaModel flujoDenuncia) {
        this.flujoDenuncia = flujoDenuncia;
    }

    @Override
    public void run() {
        datosPersonalsView = new DatosPersonalesView(this);
        flujoDenuncia.subscribe(this);
    }


    public void recolectarDatos(String nombre, String apellidoPaterno,
                                String apellidoMaterno, TipoDocumento tipoDocumento,
                                String idDocumento, String email,String celular,String edad){

        try {
            DatosPersonales datosPersonales = datosPersonalesModel.crearDatosPersonales(
                    nombre,
                    apellidoPaterno,
                    apellidoMaterno,
                    tipoDocumento,
                    idDocumento,
                    email,
                    celular,
                    edad
            );

            flujoDenuncia.setDatosPersonales(datosPersonales);
            nextView();

        }catch (IllegalArgumentException e){
            datosPersonalsView.show_error(e.getMessage());
        }

    }

    public void nextView(){
        changeView("Ubigeo");
    }

    public void previousView(){
        changeView("Terminos y Condiciones");
    }

    public void limpiarView() { datosPersonalsView.clear_fields();}

    public DatosPersonalesView getView() {
        return datosPersonalsView;
    }

    @Override
    public void update(String evento) {
        if(evento.equals("RESET")){
            limpiarView();
        }
    }
}
