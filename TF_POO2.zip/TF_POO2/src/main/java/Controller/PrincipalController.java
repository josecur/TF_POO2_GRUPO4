package Controller;

import Interfaces.Controller;
import View.PrincipalView;

public class PrincipalController extends Controller {
    private PrincipalView principalView;


    @Override
    public void run() {
        principalView = new PrincipalView(this);
    }

    public PrincipalView getView() {
        return principalView;
    }

    public void nextView(){
        changeView("Terminos y Condiciones");
    }
}
