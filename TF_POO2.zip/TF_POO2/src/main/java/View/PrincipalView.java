package View;

import Controller.PrincipalController;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import java.awt.*;

public class PrincipalView extends JPanel implements View {
    private PrincipalController controller;
    private JButton btnHacerDenuncia;

    private ScrollPane vistaPrincipal = new ScrollPane();
    private Button btn_denuncias;

    public PrincipalView(PrincipalController principalController) {
        this.controller = principalController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {
        setLayout(new BorderLayout());
        setBackground(Color.decode("#d8cfce"));  // fondo estilizado

        // Título con fuente serif o personalizada
        JLabel lblTitulo = new JLabel("NO TE QUEDES CALLADO");
        lblTitulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",60f)); // O usa FontUtil si tienes un .ttf
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 10, 0));
        lblTitulo.setForeground(Color.BLACK);
        add(lblTitulo, BorderLayout.NORTH);

        // Imagen
        JLabel lblImagen = new JLabel();
        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
        lblImagen.setVerticalAlignment(SwingConstants.CENTER);

        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/assets/denuncia_logo.png"));
            Image scaled = icon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
            lblImagen.setIcon(new ImageIcon(scaled));
        } catch (Exception e) {
            lblImagen.setText("Imagen no encontrada");
            lblImagen.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        }

        add(lblImagen, BorderLayout.CENTER);
// Panel inferior con botón y texto "GRUPO 4"
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBackground(Color.decode("#d8cfce"));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));

// Texto "GRUPO 4"
        JLabel lblGrupo4 = new JLabel("GRUPO 4");
        lblGrupo4.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",20f));
        lblGrupo4.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblGrupo4.setForeground(Color.DARK_GRAY);
        lblGrupo4.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        bottomPanel.add(lblGrupo4);

// Botón
        btnHacerDenuncia = new JButton("HACER UNA DENUNCIA");
        btnHacerDenuncia.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",18f));
        btnHacerDenuncia.setBackground(Color.BLACK);
        btnHacerDenuncia.setForeground(Color.WHITE);
        btnHacerDenuncia.setFocusPainted(false);
        btnHacerDenuncia.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnHacerDenuncia.setPreferredSize(new Dimension(300, 50));
        btnHacerDenuncia.addActionListener(e -> controller.nextView());
        bottomPanel.add(btnHacerDenuncia);

        add(bottomPanel, BorderLayout.SOUTH);

    }
}
