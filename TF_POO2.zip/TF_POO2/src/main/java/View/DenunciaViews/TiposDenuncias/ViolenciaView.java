package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.ViolenciaController;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import java.awt.*;

public class ViolenciaView extends JPanel implements View {
    private ViolenciaController violenciaController;
    private GridBagConstraints gbc;

    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextArea txt_descripcion;

    private JRadioButton rdb_agresores_si;
    private JRadioButton rdb_agresores_no;
    private JRadioButton rdb_testigos_si;
    private JRadioButton rdb_testigos_no;
    private JRadioButton rdb_usoDeObjetos_si;
    private JRadioButton rdb_usoDeObjetos_no;
    private JTextField txt_objetos;
    private JTextField txt_heridas;
    private JComboBox cmb_gravedadHeridas;
    private JRadioButton rdb_hospitalizacion_si;
    private JRadioButton rdb_hospitalizacion_no;

    public ViolenciaView(ViolenciaController violenciaController){
        this.violenciaController = violenciaController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {
        setLayout(new GridBagLayout());
        setBackground(Color.decode("#d8cfce"));

        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;

        addLabel("VICTIMA", 0, y);
        txt_victima = addTextField(1, y++, 2);

        addLabel("AGRESOR", 0, y);
        txt_agresor = addTextField(1, y, 1);
        cmb_relacionAgresor = addComboBox(new String[]{"NINGUNA", "FAMILIAR", "CONOCIDO", "PAREJA", "OTRO"}, 2, y++, 1);
        addRightLabel("RELACIÓN CON EL AGRESOR", 2, y - 1);


        addLabel("¿HUBO TESTIGOS?", 0, y);
        JPanel panelTestigos = createRadioPanel("SI", "NO");
        rdb_testigos_si = (JRadioButton) panelTestigos.getComponent(0);
        rdb_testigos_no = (JRadioButton) panelTestigos.getComponent(1);
        addComponent(panelTestigos, 1, y++, 2);


        addLabel("¿HUBO OBJTO ?", 0, y);
        JPanel panelobjeto = createRadioPanel("SI", "NO");
        rdb_usoDeObjetos_si = (JRadioButton) panelobjeto.getComponent(0);
        rdb_usoDeObjetos_no = (JRadioButton) panelobjeto.getComponent(1);
        addComponent(panelobjeto, 1, y++, 2);

        addLabel("OBJETO", 0, y);
        txt_objetos = addTextField(1, y++, 2);

        addLabel("¿REQUIRIÓ HOSPITALIZACIÓN?", 0, y);
        JPanel panelHosp = createRadioPanel("SI", "NO");
        rdb_hospitalizacion_si = (JRadioButton) panelHosp.getComponent(0);
        rdb_hospitalizacion_no = (JRadioButton) panelHosp.getComponent(1);
        addComponent(panelHosp, 1, y++, 2);

        addLabel("DESCRIPCIÓN DE LOS HECHOS", 0, y);
        txt_descripcion = addTextArea(1, y++, 2);
    }

    // Helpers para paneles con etiquetas y campos o radios
    private JPanel labelWithField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Color.decode("#eeeeee"));

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(Color.BLACK);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(150, 30));

        panel.add(label, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private JPanel labelWithRadios(String labelText, JRadioButton r1, JRadioButton r2) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.decode("#eeeeee"));

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(Color.BLACK);

        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        radioPanel.setBackground(Color.decode("#eeeeee"));
        radioPanel.add(r1);
        radioPanel.add(r2);

        panel.add(label);
        panel.add(radioPanel);
        return panel;
    }

    public void reset() {
        txt_victima.setText("");
        txt_agresor.setText("");
        cmb_relacionAgresor.setSelectedIndex(0);
        //rdb_agresores_si.setSelected(false);
        //rdb_agresores_no.setSelected(false);
        rdb_testigos_si.setSelected(false);
        rdb_testigos_no.setSelected(false);
        rdb_usoDeObjetos_si.setSelected(false);
        rdb_usoDeObjetos_no.setSelected(false);
        txt_objetos.setText("");
        //txt_heridas.setText("");
        //cmb_gravedadHeridas.setSelectedIndex(0);
        rdb_hospitalizacion_si.setSelected(false);
        rdb_hospitalizacion_no.setSelected(false);
        txt_descripcion.setText("");
    }


    //-----------------------------------------------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf", 14f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private void addRightLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        add(label, gbc);
        gbc.anchor = GridBagConstraints.WEST;
    }

    private JTextField addTextField(int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        addComponent(field, x, y, width);
        return field;
    }

    private JComboBox<String> addComboBox(String[] items, int x, int y, int width) {
        JComboBox<String> combo = new JComboBox<>(items);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setPreferredSize(new Dimension(500, 40));
        combo.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        addComponent(combo, x, y, width);
        return combo;
    }

    private JPanel createRadioPanel(String opt1, String opt2) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panel.setBackground(getBackground());

        JRadioButton rb1 = new JRadioButton(opt1);
        JRadioButton rb2 = new JRadioButton(opt2);

        rb1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rb2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rb1.setBackground(getBackground());
        rb2.setBackground(getBackground());
        rb1.setForeground(new Color(90, 0, 160));
        rb2.setForeground(new Color(90, 0, 160));

        ButtonGroup group = new ButtonGroup();
        group.add(rb1);
        group.add(rb2);
        panel.add(rb1);
        panel.add(rb2);

        return panel;
    }

    private JTextArea addTextArea(int x, int y, int width) {
        JTextArea area = new JTextArea(5,50);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(600, 150));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        addComponent(scroll, x, y, width);
        return area;
    }

    private void addComponent(JComponent comp, int x, int y, int width) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

    private void styleRadio(JRadioButton radio) {
        radio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        radio.setBackground(Color.decode("#eeeeee"));
    }


    public String getVictima(){
        return txt_victima.getText();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }

    public Boolean getAgresores(){
        return rdb_agresores_si.isSelected();
    }

    public String getGravedadHeridas(){
        return (String)cmb_gravedadHeridas.getSelectedItem();
    }

    public Boolean getHospitalizacion(){
        return rdb_hospitalizacion_si.isSelected();
    }

    public String getHeridas(){
        return  txt_heridas.getText();
    }

    public String getObjetos(){
        return txt_objetos.getText();
    }

    public Boolean getUsoDeObjetos(){
        return rdb_usoDeObjetos_si.isSelected();
    }

    public Boolean getTestigos(){
        return rdb_testigos_si.isSelected();
    }
}
