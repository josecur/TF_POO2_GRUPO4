package View.DenunciaViews;

import Controller.DenunciaControllers.UbigeoController;
import Interfaces.View;
import Util.FontUtil;
import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Distrito;
import Util.ubicacionDB.Provincia;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class UbigeoView extends JPanel implements View {
    private UbigeoController ubigeoController;
    private GridBagConstraints gbc;

    private JComboBox<Departamento> cmb_departamentos;
    private JComboBox<Provincia> cmb_provincias;
    private JComboBox<Distrito> cmb_distritos;
    private JTextField txt_direccion;
    private JTextArea txt_detalles;

    private JButton btn_siguiente;
    private JButton btn_atras;


    public UbigeoView(UbigeoController ubigeoController){
        this.ubigeoController = ubigeoController;

        iniciarComponentes();

    }

    @Override
    public void iniciarComponentes() {
        make_frame();
        make_encabezado();

        make_departamentos();
        make_provincias();
        make_distritos();
        make_direccion();
        make_detalles();
        make_siguiente();
        make_atras();

    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        setBackground(new Color(194, 190, 190));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
    }

    //---------------------------------------------------------------------------------

    private void make_encabezado() {
        JLabel icono = new JLabel(new ImageIcon("/assets/Map pin.png"));
        JLabel titulo = new JLabel("UBICACIÓN DE LOS HECHOS");
        titulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",46f));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(194, 190, 190));
        headerPanel.add(icono);
        headerPanel.add(titulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        add(headerPanel, gbc);
        gbc.gridwidth = 1;
    }

    private void make_departamentos(){
        cmb_departamentos = new JComboBox<>();
        addLabel("DEPARTAMENTO", 0, 1);

        cmb_departamentos.setPreferredSize(new Dimension(300, 40));
        cmb_departamentos.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));

        addComponent(cmb_departamentos, 0, 2, 1);

        cargarDepartamentos();
    }


    private void make_provincias(){
        cmb_provincias = new JComboBox<>();
        addLabel("PROVINCIA", 1, 1);

        cmb_provincias.setPreferredSize(new Dimension(300, 40));
        cmb_provincias.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));

        addComponent(cmb_provincias, 1, 2, 1);


        cmb_departamentos.addActionListener(e -> {
            cmb_provincias.removeAllItems();
            cmb_distritos.removeAllItems();
            Departamento seleccionado = (Departamento) cmb_departamentos.getSelectedItem();

            if (seleccionado != null) {
                cargarProvincias(seleccionado.getId());
            }

        });
    }

    private void make_distritos(){
        cmb_distritos = new JComboBox<>();
        addLabel("DISTRITO", 2, 1);

        cmb_distritos.setPreferredSize(new Dimension(300, 40));
        cmb_distritos.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));

        addComponent(cmb_distritos, 2, 2, 1);

        cmb_provincias.addActionListener(e -> {
            cmb_distritos.removeAllItems();
            Provincia seleccionado = (Provincia) cmb_provincias.getSelectedItem();

            if (seleccionado != null) {
                cargarDistritos(seleccionado.getId());
            }

        });
    }

    private void make_direccion(){
        addLabel("Dirección:", 0, 3);
        txt_direccion = addTextField(0, 4, 3);
    }

    private void make_detalles(){
        addLabel("Detalles: ",0,5);

        txt_detalles = new JTextArea(6, 40);
        txt_detalles.setLineWrap(true);
        txt_detalles.setWrapStyleWord(true);
        txt_detalles.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        JScrollPane scroll = new JScrollPane(txt_detalles);
        scroll.setPreferredSize(new Dimension(600, 150));
        addComponent(scroll, 0, 6, 3);

    }

    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_siguiente.setBackground(Color.BLACK);
        btn_siguiente.setForeground(Color.WHITE);
        btn_siguiente.setFocusPainted(false);
        btn_siguiente.setPreferredSize(new Dimension(150, 45));
        btn_siguiente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_siguiente.addActionListener(e -> {

            Departamento departamento = (Departamento)cmb_departamentos.getSelectedItem();
            Distrito distrito = (Distrito) cmb_distritos.getSelectedItem();
            Provincia provincia = (Provincia) cmb_provincias.getSelectedItem();
            String direccion = txt_direccion.getText();
            String detalles = txt_detalles.getText();

            ubigeoController.recolectarDatos(departamento,provincia,distrito,direccion,detalles);
        });

        gbc.anchor = GridBagConstraints.EAST;
        addComponent(btn_siguiente, 2, 8, 1);
    }

    private void make_atras(){
        btn_atras = new JButton("Atrás");
        btn_atras.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_atras.setBackground(Color.BLACK);
        btn_atras.setForeground(Color.WHITE);
        btn_atras.setFocusPainted(false);
        btn_atras.setPreferredSize(new Dimension(150, 45));
        btn_atras.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_atras.addActionListener(e -> {
            ubigeoController.previousView();

        });

        gbc.anchor = GridBagConstraints.WEST;
        addComponent(btn_atras, 0, 8, 1);
    }

    public void clear_fields(){
        cmb_departamentos.setSelectedIndex(1);
        cmb_provincias.setSelectedIndex(1);
        cmb_distritos.setSelectedIndex(1);
        txt_detalles.setText("");
        txt_direccion.setText("");
    }

    public void show_error(String mensaje){
        JOptionPane.showMessageDialog(null,mensaje,"ERROR",JOptionPane.WARNING_MESSAGE);
    }


    //CARGAR COMBOS-----------------------------------------------------------------------------------

    private void cargarDepartamentos() {
        List<Departamento> departamentos = ubigeoController.fill_Departamentos();

        for (Departamento d : departamentos) {
            cmb_departamentos.addItem(d);
        }

        cmb_departamentos.setRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if(value instanceof Departamento){
                    Departamento d = (Departamento) value;
                    setText(d.getName());
                }

                return this;
            }
        });

    }

    private void cargarProvincias(String departamentoId) {
        List<Provincia> provincias = ubigeoController.fill_Provincias(departamentoId);

        for (Provincia p : provincias) {
            cmb_provincias.addItem(p);
        }

        cmb_provincias.setRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if(value instanceof Provincia){
                    Provincia d = (Provincia) value;
                    setText(d.getName());
                }

                return this;
            }
        });

    }

    private void cargarDistritos(String provinciaId) {
        List<Distrito> distritos = ubigeoController.fill_Distritos(provinciaId);

        for (Distrito d : distritos) {
            cmb_distritos.addItem(d);
        }

        cmb_distritos.setRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if(value instanceof Distrito){
                    Distrito d = (Distrito) value;
                    setText(d.getName());
                }

                return this;
            }
        });
    }

    //---------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private JTextField addTextField(int x, int y, int gridWidth) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(field, x, y, gridWidth);
        return field;
    }

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

}
