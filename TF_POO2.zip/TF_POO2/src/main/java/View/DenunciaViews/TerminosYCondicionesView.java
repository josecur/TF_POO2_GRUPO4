package View.DenunciaViews;

import Controller.DenunciaControllers.TerminosYCondicionesController;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import java.awt.*;

public class TerminosYCondicionesView extends JPanel implements View {
    private TerminosYCondicionesController terminosYCondicionesController;
    private GridBagConstraints gbc;


    private JCheckBox chk_aceptarTerminos;
    private JTextArea txtA_terminosArea;
    private JButton btn_siguiente;
    private JButton btn_atras;

    public TerminosYCondicionesView(TerminosYCondicionesController terminosYCondicionesController){
        this.terminosYCondicionesController = terminosYCondicionesController;

        iniciarComponentes();
    }


    @Override
    public void iniciarComponentes() {

        make_frame();
        make_encabezado();
        make_TerminosYCondiciones();
        make_checkbox();
        make_siguiente();
        make_atras();

    }

    private void make_encabezado() {
        JLabel titulo = new JLabel("TERMINOS Y CONDICIONES");
        titulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",46f));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(194, 190, 190));
        headerPanel.add(titulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 5;
        add(headerPanel, gbc);
        gbc.gridwidth = 1;
    }


    private void make_frame() {
        setLayout(new GridBagLayout());
        setBackground(new Color(194, 190, 190));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
    }

    public void make_TerminosYCondiciones(){
        txtA_terminosArea = new JTextArea(15, 60);
        txtA_terminosArea.setFont(new Font("Tahoma", Font.ITALIC, 18));
        txtA_terminosArea.setLineWrap(true);
        txtA_terminosArea.setWrapStyleWord(true);
        txtA_terminosArea.setEditable(false);
        txtA_terminosArea.setText(terminosYCondicionesController.leerDocumento());

        JScrollPane scroll = new JScrollPane(txtA_terminosArea);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 20, 20, 20);
        add(scroll, gbc);

    }

    public void make_checkbox(){
        chk_aceptarTerminos = new JCheckBox("He leído y acepto los términos y condiciones");
        chk_aceptarTerminos.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",16f));
        chk_aceptarTerminos.setBackground(new Color(194, 190, 190));
        addComponent(chk_aceptarTerminos,1,2,2);

        chk_aceptarTerminos.addActionListener(e -> {
            btn_siguiente.setEnabled(chk_aceptarTerminos.isSelected());
        });
    }


    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_siguiente.setBackground(Color.BLACK);
        btn_siguiente.setForeground(Color.WHITE);
        btn_siguiente.setEnabled(false);
        btn_siguiente.setPreferredSize(new Dimension(150, 45));
        btn_siguiente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_siguiente.addActionListener(e -> {
            terminosYCondicionesController.nextView();
        });

        gbc.anchor = GridBagConstraints.EAST;
        addComponent(btn_siguiente, 4, 9, 1);
    }

    private void make_atras(){
        btn_atras = new JButton("Atras");
        btn_atras.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_atras.setBackground(Color.BLACK);
        btn_atras.setForeground(Color.WHITE);
        btn_atras.setFocusPainted(false);
        btn_atras.setPreferredSize(new Dimension(150, 45));
        btn_atras.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_atras.addActionListener(e -> {
            terminosYCondicionesController.previousView();
        });

        gbc.anchor = GridBagConstraints.WEST;
        addComponent(btn_atras, 0, 9, 1);
    }


    //---------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

    public void clear_fields(){

    }

    public void show_error(String mensaje){
        JOptionPane.showMessageDialog(null,mensaje,"ERROR",JOptionPane.WARNING_MESSAGE);
    }

}
