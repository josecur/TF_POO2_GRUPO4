package View.DenunciaViews;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.TipoDenuncia;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;

public class DenunciaFormView extends JPanel implements View {
    private DenunciaFormController denunciaFormController;
    private GridBagConstraints gbc;

    private CardLayout cardLayout = new CardLayout();
    private JPanel panelDenuncia = new JPanel(cardLayout);

    private JComboBox<TipoDenuncia> cmb_TipoDenuncias;
    private JFormattedTextField txt_date;
    private JFormattedTextField txt_hour;
    private JButton btn_siguiente;
    private JButton btn_atras;

    public DenunciaFormView(DenunciaFormController denunciaFormController){
        this.denunciaFormController = denunciaFormController;

        iniciarComponentes();
    }


    @Override
    public void iniciarComponentes() {
        make_frame();

        make_superior();
        make_center();
        make_south();

    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        setBackground(new Color(194, 190, 190));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
    }

    private void make_encabezado(){
        //JLabel icono = new JLabel(new ImageIcon(getClass().getResource("/assets/Shield.png")));
        JLabel titulo = new JLabel("FORMULARIO DE DENUNCIA");
        titulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",46f));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(194, 190, 190));
        //headerPanel.add(icono);
        headerPanel.add(titulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 6;
        add(headerPanel, gbc);
        gbc.gridwidth = 1;
    }

    private void make_superior(){
        make_encabezado();
        make_tipoDenuncia();
        make_date();
        make_hour();
    }

    private void make_center(){
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 6;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        add(panelDenuncia, gbc);

        agregarViews();
    }

    private void make_south(){
        make_atras();
        make_siguiente();

    }

    private void make_tipoDenuncia(){
        addLabel("Tipo de Denuncia:", 0, 1);
        cmb_TipoDenuncias = new JComboBox<>();
        cmb_TipoDenuncias.setPreferredSize(new Dimension(300, 40));
        cmb_TipoDenuncias.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));

        cargarTipoDenuncia(cmb_TipoDenuncias);

        addComponent(cmb_TipoDenuncias,1,1,1);


        cmb_TipoDenuncias.addActionListener(e -> {
            TipoDenuncia txt = (TipoDenuncia) cmb_TipoDenuncias.getSelectedItem();
            denunciaFormController.changeView_tipoDenuncia(txt.getNombre());

        });
    }

    private void make_date(){
        addLabel("Fecha:", 2, 1);
        try {
            //dd/MM/YYYY
            txt_date = new JFormattedTextField(new MaskFormatter("##/##/####"));
            txt_date.setFocusLostBehavior(JFormattedTextField.PERSIST);

        } catch (Exception e) {
            e.printStackTrace();
        }
        txt_date.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        txt_date.setPreferredSize(new Dimension(300, 40));
        txt_date.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(txt_date,3,1,1);

    }

    private void make_hour(){
        addLabel("Hora:", 4, 1);
        try {
            //HH:MM
            txt_hour = new JFormattedTextField(new MaskFormatter("##:##"));
            txt_hour.setFocusLostBehavior(JFormattedTextField.PERSIST);

        } catch (Exception e) {
            e.printStackTrace();
        }

        txt_hour.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        txt_hour.setPreferredSize(new Dimension(300, 40));
        txt_hour.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(txt_hour,5,1,1);
    }



    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_siguiente.setBackground(Color.BLACK);
        btn_siguiente.setForeground(Color.WHITE);
        btn_siguiente.setFocusPainted(false);
        btn_siguiente.setPreferredSize(new Dimension(150, 45));
        btn_siguiente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_siguiente.addActionListener(e -> {

            try {
                TipoDenuncia tipo = (TipoDenuncia) cmb_TipoDenuncias.getSelectedItem();
                String fecha = txt_date.getText();
                String hora = txt_hour.getText();

                denunciaFormController.recolectarDatos(tipo, fecha, hora);


            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"Ha ocurrido un error, intente mas tarde");
            }


        });

        gbc.anchor = GridBagConstraints.EAST;
        addComponent(btn_siguiente, 5, 3, 1);
    }

    private void make_atras(){
        btn_atras = new JButton("Atras");
        btn_atras.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_atras.setBackground(Color.BLACK);
        btn_atras.setForeground(Color.WHITE);
        btn_atras.setFocusPainted(false);
        btn_atras.setPreferredSize(new Dimension(150, 45));
        btn_atras.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_atras.addActionListener(e -> {
            denunciaFormController.previousView();
        });

        gbc.anchor = GridBagConstraints.WEST;
        addComponent(btn_atras, 0, 3, 1);
    }



    public void clear_fields(){
        txt_date.setText("");
        txt_hour.setText("");
    }
    //----------------------------------------------------------------------------------------------

    private void agregarViews(){
        panelDenuncia.add(denunciaFormController.getAbusoSexualView(),TipoDenuncia.ABUSO_SEXUAL.name());
        panelDenuncia.add(denunciaFormController.getAcosoSexualView(),TipoDenuncia.ACOSO_SEXUAL.name());
        panelDenuncia.add(denunciaFormController.getAcosoView(), TipoDenuncia.ACOSO.name());
        panelDenuncia.add(denunciaFormController.getDomesticaView(), TipoDenuncia.DOMESTICA.name());
        panelDenuncia.add(denunciaFormController.getPsicologicaView(), TipoDenuncia.PSICOLOGICA.name());
        panelDenuncia.add(denunciaFormController.getViolenciaView(), TipoDenuncia.VIOLENCIA.name());

        cardLayout.show(panelDenuncia, TipoDenuncia.ABUSO_SEXUAL.name());

    }

    public void mostrarPanelDenuncia(String namePanel){
        cardLayout.show(panelDenuncia, namePanel);
    }

    public void show_error(String mensaje){
        JOptionPane.showMessageDialog(null,mensaje,"ERROR",JOptionPane.WARNING_MESSAGE);
    }

    public void show_confirmation(){
        JOptionPane.showMessageDialog(null,"Su denuncia ha sido registrada");
    }



    //----------------------------------------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private JTextField addTextField(int x, int y, int gridWidth) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(field, x, y, gridWidth);
        return field;
    }

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

    private void cargarTipoDenuncia(JComboBox<TipoDenuncia> combo){
        for(TipoDenuncia tipo : TipoDenuncia.values()){
            combo.addItem(tipo);
        }

        combo.setRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof TipoDenuncia) {
                    TipoDenuncia c = (TipoDenuncia) value;
                    setText(String.format("%s", c.getNombre()));
                }

                return this;
            }
        });

    }
}
