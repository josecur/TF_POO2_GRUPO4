package Interfaces;

import Model.Strategy.RiesgoAbusoSexual;
import Model.Strategy.RiesgoAcoso;
import Model.Strategy.RiesgoViolencia;
import Util.Denuncia.Denuncia;

public enum TipoDenuncia {
    ABUSO_SEXUAL("Abuso Sexual", new RiesgoAbusoSexual()),
    ACOSO("Acoso", new RiesgoAcoso()),
    ACOSO_SEXUAL("Acoso Sexual", new RiesgoAcoso()),
    DOMESTICA("Violencia Domestica", new RiesgoViolencia()),
    PSICOLOGICA("Violencia Psicológica", new RiesgoAcoso()),
    VIOLENCIA("Violencia", new RiesgoViolencia());


    private String nombre;
    private RiesgoBehavior riesgo;

    TipoDenuncia(String nombre, RiesgoBehavior riesgo) {
        this.nombre = nombre;
        this.riesgo = riesgo;
    }

    public NivelRiesgo calcularRiesgo(Denuncia detalles) {
        return riesgo.evaluarRiesgo(detalles);
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}

