package Interfaces;

public interface FuncionesRepository {

    String nuevoID(String abreviacion);
}
