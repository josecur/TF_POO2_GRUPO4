package Interfaces;

public interface View {

    void iniciarComponentes();
}
