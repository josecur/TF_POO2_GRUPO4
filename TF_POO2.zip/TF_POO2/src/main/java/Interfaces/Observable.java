package Interfaces;

public interface Observable {

    void subscribe(Listener listener);

    void unsubscribe(Listener listener);

    void notifyEvent(String evento);
}
