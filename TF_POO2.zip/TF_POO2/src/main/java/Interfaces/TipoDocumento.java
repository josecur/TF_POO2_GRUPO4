package Interfaces;

public enum TipoDocumento {
    DNI,
    CE
}
