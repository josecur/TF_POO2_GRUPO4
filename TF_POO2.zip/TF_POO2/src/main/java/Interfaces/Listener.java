package Interfaces;

public interface Listener {

    void update(String evento);

}
