package Util.ubicacionDB;

public class Distrito {
    private String id;
    private String name;
    private String province_id;
    private String department_id;

    public Distrito(String id, String name, String province_id, String department_id) {
        this.id = id;
        this.name = name;
        this.province_id = province_id;
        this.department_id = department_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvince_id() {
        return province_id;
    }

    public void setProvince_id(String province_id) {
        this.province_id = province_id;
    }

    public String getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public static Distrito fromString(String data){ //"1,Karen"

        String[] partes = data.split("-");

        return new Distrito(partes[0],partes[1],partes[2],partes[3]);

    }
}
