package Util;

import java.awt.*;
import java.io.InputStream;

public class FontUtil {

    public static Font loadFont(String resourcePath, float size) {
        try {
            InputStream is = FontUtil.class.getResourceAsStream(resourcePath);
            if (is == null) throw new RuntimeException("Fuente no encontrada: " + resourcePath);
            Font font = Font.createFont(Font.TRUETYPE_FONT, is);
            return font.deriveFont(size);
        } catch (Exception e) {
            return new Font("Segoe UI", Font.BOLD, (int) size); // fallback
        }
    }
}
