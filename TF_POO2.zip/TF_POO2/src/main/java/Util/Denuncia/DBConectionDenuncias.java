package Util.Denuncia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConectionDenuncias {
    static String url = "jdbc:sqlserver://localhost:50807;databaseName=DENUNCIAS;encrypt=true;trustServerCertificate=true";
    static String user = "tfPoo";
    static String pass = "dbconectar";

    public static Connection conectar(){

        Connection conn = null;

        try{
            conn = DriverManager.getConnection(url,user,pass);

            System.out.println("Conexion exitosa");

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return conn;
    }
}
