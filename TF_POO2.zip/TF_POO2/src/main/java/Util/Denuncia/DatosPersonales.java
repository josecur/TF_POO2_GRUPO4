package Util.Denuncia;

import Interfaces.TipoDocumento;

public class DatosPersonales {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private TipoDocumento tipoDocumento;
    private int idDocumento;
    private String email;
    private int celular;
    private int edad;

    public DatosPersonales(String nombre, String apellidoPaterno,
                           String apellidoMaterno, TipoDocumento tipoDocumento,
                           int idDocumento, String email,int celular,int edad) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.tipoDocumento = tipoDocumento;
        this.idDocumento = idDocumento;
        this.email = email;
        this.celular = celular;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public int getIdDocumento() {
        return idDocumento;
    }

    public String getEmail() {
        return email;
    }

    public int getCelular() {
        return celular;
    }

    public int getEdad() {
        return edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public void setIdDocumento(int idDocumento) {
        this.idDocumento = idDocumento;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
