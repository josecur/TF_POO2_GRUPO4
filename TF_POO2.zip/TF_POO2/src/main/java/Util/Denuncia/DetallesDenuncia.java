package Util.Denuncia;

import Model.DetallesDenunciaBuilder;

public class DetallesDenuncia {
    private String fechaSuceso;
    private String horaSuceso;
    private String victima;
    private String agresor;
    private String relacionAgresor;
    private String medio;
    private Boolean testigos;
    private String frecuencia;
    private Boolean menoresInvolucrados;
    private String sintomas;
    private String heridas;
    private String gravedadHeridas;
    private Boolean hospitalizacion;
    private Boolean usoDeObjetos;
    private Boolean agresores;
    private String objetos;
    private String descripcion;


    public DetallesDenuncia(DetallesDenunciaBuilder builder){
        this.fechaSuceso = builder.fechaSuceso;
        this.horaSuceso = builder.horaSuceso;
        this.victima = builder.victima;
        this.agresor = builder.agresor;
        this.relacionAgresor = builder.relacionAgresor;
        this.medio = builder.medio;
        this.testigos = builder.testigos;
        this.frecuencia = builder.frecuencia;
        this.menoresInvolucrados = builder.menoresInvolucrados;
        this.sintomas = builder.sintomas;
        this.heridas = builder.heridas;
        this.gravedadHeridas = builder.gravedadHeridas;
        this.hospitalizacion = builder.hospitalizacion;
        this.usoDeObjetos = builder.usoDeObjetos;
        this.agresores = builder.agresores;
        this.objetos = builder.objetos;
        this.descripcion = builder.descripcion;
    }

    public void setFechaSuceso(String  fechaSuceso) {
        this.fechaSuceso = fechaSuceso;
    }

    public void setHoraSuceso(String horaSuceso) {
        this.horaSuceso = horaSuceso;
    }

    public String getFechaSuceso() { return fechaSuceso; }

    public String getHoraSuceso() { return horaSuceso; }

    public String getVictima() {
        return victima;
    }

    public String getAgresor() {
        return agresor;
    }

    public String getRelacionAgresor() {
        return relacionAgresor;
    }

    public String getMedio() {
        return medio;
    }

    public Boolean isTestigos() {
        return testigos;
    }

    public String getFrecuencia() {
        return frecuencia;
    }

    public Boolean isMenoresInvolucrados() {
        return menoresInvolucrados;
    }

    public String getSintomas() {
        return sintomas;
    }

    public String getHeridas() {
        return heridas;
    }

    public String getGravedadHeridas() {
        return gravedadHeridas;
    }

    public Boolean isHospitalizacion() {
        return hospitalizacion;
    }

    public Boolean isUsoDeObjetos() {
        return usoDeObjetos;
    }

    public Boolean isAgresores() {
        return agresores;
    }

    public String getObjetos() {
        return objetos;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
