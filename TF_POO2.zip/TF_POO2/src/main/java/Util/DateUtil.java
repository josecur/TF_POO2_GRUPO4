package Util;

import java.text.SimpleDateFormat;
import java.util.Date;


public class DateUtil {

    public static java.sql.Date formatDateToSQL(String fechaOriginal) {
        if (fechaOriginal == null || fechaOriginal.isBlank()) {
            return null;
        }

        try {
            SimpleDateFormat formatoEntrada = new SimpleDateFormat("dd/MM/yyyy");
            formatoEntrada.setLenient(false);
            Date fecha = formatoEntrada.parse(fechaOriginal);
            return new java.sql.Date(fecha.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


}
