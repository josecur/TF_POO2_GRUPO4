package Model;

import Util.Denuncia.DetallesDenuncia;
import Util.StringUtil;

public class DetallesDenunciaBuilder {
    public String fechaSuceso;
    public String horaSuceso;
    public String victima;
    public String agresor;
    public String relacionAgresor;
    public String medio;
    public Boolean testigos;
    public String frecuencia;
    public Boolean menoresInvolucrados;
    public String sintomas;
    public String heridas;
    public String gravedadHeridas;
    public Boolean hospitalizacion;
    public Boolean usoDeObjetos;
    public Boolean agresores;
    public String objetos;
    public String descripcion;

    public DetallesDenunciaBuilder fechaSuceso(String fechaSuceso) {
        this.fechaSuceso = fechaSuceso;
        return this;
    }

    public DetallesDenunciaBuilder horaSuceso(String horaSuceso) {
        this.horaSuceso = StringUtil.nullIfBlank(horaSuceso);
        return this;
    }

    public DetallesDenunciaBuilder victima(String victima) {
        this.victima = StringUtil.nullIfBlank(victima);
        return this;
    }

    public DetallesDenunciaBuilder agresor(String agresor) {
        this.agresor = StringUtil.nullIfBlank(agresor);
        return this;
    }

    public DetallesDenunciaBuilder relacionAgresor(String relacionAgresor) {
        this.relacionAgresor = relacionAgresor;
        return this;
    }

    public DetallesDenunciaBuilder medio(String medio) {
        this.medio = medio;
        return this;
    }

    public DetallesDenunciaBuilder testigos(Boolean testigos) {
        this.testigos = testigos;
        return this;
    }

    public DetallesDenunciaBuilder frecuencia(String frecuencia) {
        this.frecuencia = frecuencia;
        return this;
    }

    public DetallesDenunciaBuilder menoresInvolucrados(Boolean menoresInvolucrados) {
        this.menoresInvolucrados = menoresInvolucrados;
        return this;
    }

    public DetallesDenunciaBuilder sintomas(String sintomas) {
        this.sintomas = StringUtil.nullIfBlank(sintomas);
        return this;
    }

    public DetallesDenunciaBuilder heridas(String heridas) {
        this.heridas = StringUtil.nullIfBlank(heridas);
        return this;
    }

    public DetallesDenunciaBuilder gravedadHeridas(String gravedadHeridas) {
        this.gravedadHeridas = gravedadHeridas;
        return this;
    }

    public DetallesDenunciaBuilder hospitalizacion(Boolean hospitalizacion) {
        this.hospitalizacion = hospitalizacion;
        return this;
    }

    public DetallesDenunciaBuilder usoDeObjetos(Boolean usoDeObjetos) {
        this.usoDeObjetos = usoDeObjetos;
        return this;
    }

    public DetallesDenunciaBuilder agresores(Boolean agresores) {
        this.agresores = agresores;
        return this;
    }

    public DetallesDenunciaBuilder objetos(String objetos) {
        this.objetos = StringUtil.nullIfBlank(objetos);
        return this;
    }

    public DetallesDenunciaBuilder descripcion(String descripcion) {
        this.descripcion = StringUtil.nullIfBlank(descripcion);
        return this;
    }

    public String getFechaSuceso() {
        return fechaSuceso;
    }

    public String getHoraSuceso() {
        return horaSuceso;
    }

    public DetallesDenuncia build(){
        return new DetallesDenuncia(this);
    }
}
