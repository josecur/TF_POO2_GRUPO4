package Model;

import Interfaces.TipoDocumento;
import Util.Denuncia.DatosPersonales;

public class DatosPersonalesModel {
    public DatosPersonales crearDatosPersonales(String nombre, String apellidoPaterno,
                                                String apellidoMaterno, TipoDocumento tipoDocumento,
                                                String idDocumento, String email,String celular,
                                                String edad) throws IllegalArgumentException{

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre vacío. Complete el nombre, por favor.");
        }

        if (apellidoPaterno == null || apellidoPaterno.trim().isEmpty()) {
            throw new IllegalArgumentException("Apellido paterno vacío. Complete el campo.");
        }

        if (apellidoMaterno == null || apellidoMaterno.trim().isEmpty()) {
            throw new IllegalArgumentException("Apellido materno vacío. Complete el campo.");
        }

        if (tipoDocumento == null) {
            throw new IllegalArgumentException("Tipo de documento no seleccionado.");
        }

        if (idDocumento == null || idDocumento.isEmpty()) {
            throw new IllegalArgumentException("ID de documento inválido.");
        }

        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            throw new IllegalArgumentException("Email inválido.");
        }

        if (celular == null || celular.isEmpty() || celular.length() < 9) {
            throw new IllegalArgumentException("Número de celular inválido.");
        }

        if (edad == null || edad.isEmpty()) {
            throw new IllegalArgumentException("Edad inválida.");
        }

        int idDocumentoint = Integer.parseInt(idDocumento);
        int celularint = Integer.parseInt(celular);
        int edadint = Integer.parseInt(edad);


        return new DatosPersonales(
                nombre,
                apellidoPaterno,
                apellidoMaterno,
                tipoDocumento,
                idDocumentoint,
                email,
                celularint,
                edadint);
    }
}
