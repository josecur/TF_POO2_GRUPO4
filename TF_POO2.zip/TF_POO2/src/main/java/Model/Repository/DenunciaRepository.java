package Model.Repository;

import Interfaces.DenunciasRepository;
import Util.DateUtil;
import Util.Denuncia.DBConectionDenuncias;
import Util.Denuncia.Denuncia;
import Util.StatementHelper;

import java.sql.*;

public class DenunciaRepository implements DenunciasRepository {

    @Override
    public void insertarDenuncia(String idDenuncia, Denuncia denuncia) {
        String query = "INSERT INTO denuncia (idDenuncia, tipoDenuncia, estado, riesgo) " +
                "VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){


            ps.setString(1,idDenuncia);
            ps.setString(2, denuncia.getTipoDenuncia().getNombre());
            ps.setString(3, "Nueva");
            ps.setString(4, denuncia.getNivelRiesgo().name());


            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertarDatosPersonales(String idDenuncia, Denuncia denuncia) {
        String query = "INSERT INTO datos_personales (idDenuncia, nombre, apellidoPaterno, " +
                "apellidoMaterno, tipoDocumento, idDocumento, email, celular, edad) " +
                "VALUES (?, ?, ?, ?, ? ,? ,? ,? ,?)";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){

            ps.setString(1,idDenuncia);
            ps.setString(2, denuncia.getDatosPersonales().getNombre());
            ps.setString(3, denuncia.getDatosPersonales().getApellidoPaterno());
            ps.setString(4, denuncia.getDatosPersonales().getApellidoMaterno());
            ps.setString(5, denuncia.getDatosPersonales().getTipoDocumento().name());
            ps.setInt(6, denuncia.getDatosPersonales().getIdDocumento());
            ps.setString(7, denuncia.getDatosPersonales().getEmail());
            ps.setInt(8, denuncia.getDatosPersonales().getCelular());
            ps.setInt(9, denuncia.getDatosPersonales().getEdad());


            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertarUbicacion(String idDenuncia, Denuncia denuncia) {
        String query = "INSERT INTO ubicacion (idDenuncia, departamento, provincia, distrito," +
                " direccion, detallesAdicionales) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){

            StatementHelper helper = new StatementHelper(ps);


            ps.setString(1,idDenuncia);
            ps.setString(2, denuncia.getUbicacion().getDepartamento());
            ps.setString(3, denuncia.getUbicacion().getProvincia());
            ps.setString(4, denuncia.getUbicacion().getDistirto());
            helper.setString(5, denuncia.getUbicacion().getDireccion());
            helper.setString(6, denuncia.getUbicacion().getDetallesAdicionales());


            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertarDetallesDenuncia(String idDenuncia, Denuncia denuncia) {
        String query = "INSERT INTO detalles_denuncia (idDenuncia, fechaSuceso, horaSuceso, victima," +
                " agresor, relacionAgresor, medio, testigos, frecuencia, menoresInvolucrados, " +
                "sintomas, heridas, gravedadHeridas, hospitalizacion, usoDeObjetos, agresores, " +
                "objetos, descripcion) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){

            StatementHelper helper = new StatementHelper(ps);

            helper.setString(1, idDenuncia);
            java.sql.Date fechaSQL = DateUtil.formatDateToSQL(denuncia.getDetallesDenuncia().getFechaSuceso());

            ps.setDate(2, fechaSQL);
            helper.setString(3, denuncia.getDetallesDenuncia().getHoraSuceso());
            helper.setString(4, denuncia.getDetallesDenuncia().getVictima());
            helper.setString(5, denuncia.getDetallesDenuncia().getAgresor());
            helper.setString(6, denuncia.getDetallesDenuncia().getRelacionAgresor());
            helper.setString(7, denuncia.getDetallesDenuncia().getMedio());
            helper.setBoolean(8, denuncia.getDetallesDenuncia().isTestigos());
            helper.setString(9, denuncia.getDetallesDenuncia().getFrecuencia());
            helper.setBoolean(10, denuncia.getDetallesDenuncia().isMenoresInvolucrados());
            helper.setString(11, denuncia.getDetallesDenuncia().getSintomas());
            helper.setString(12, denuncia.getDetallesDenuncia().getHeridas());
            helper.setString(13, denuncia.getDetallesDenuncia().getGravedadHeridas());
            helper.setBoolean(14, denuncia.getDetallesDenuncia().isHospitalizacion());
            helper.setBoolean(15, denuncia.getDetallesDenuncia().isUsoDeObjetos());
            helper.setBoolean(16, denuncia.getDetallesDenuncia().isAgresores());
            helper.setString(17, denuncia.getDetallesDenuncia().getObjetos());
            helper.setString(18, denuncia.getDetallesDenuncia().getDescripcion());

            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public String leerDenuncia(String idDenuncia) {
        String mensaje = null;
        String query = "EXEC sp_getMensajeDenuncia ?";

        try (Connection conn = DBConectionDenuncias.conectar();
            CallableStatement ps = conn.prepareCall(query)) {

            ps.setString(1, idDenuncia);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                mensaje = rs.getString("mensaje");
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return mensaje;

    }

    @Override
    public void updateDenuncia(Denuncia denuncia) {
        String query = "";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){

            ResultSet rs = ps.executeQuery();

        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Override
    public void eliminarDenuncia(Denuncia denuncia) {

        String query = "UPDATE estado FROM denuncia SET 'Eliminada' WHERE idDenuncia = ?";

        try (Connection conn = DBConectionDenuncias.conectar();
             PreparedStatement ps = conn.prepareStatement(query)){

            ps.setInt(1, denuncia.getId());

            ps.executeQuery();



        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
