package Model.Repository;

import Interfaces.FuncionesRepository;
import Util.Denuncia.DBConectionDenuncias;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

public class ProcedimientosRepository implements FuncionesRepository {

    @Override
    public String nuevoID(String abreviacion) {
        String nuevoId = null;

        String query = "{call dbo.SiguienteId(?, ?)}";

        try (Connection conn = DBConectionDenuncias.conectar();
             CallableStatement ps = conn.prepareCall(query)) {

            ps.setString(1, abreviacion);
            ps.registerOutParameter(2, Types.VARCHAR);

            ps.execute();

            nuevoId = ps.getString(2);

        }catch (Exception e){
            e.printStackTrace();
        }

        return nuevoId;
    }
}
