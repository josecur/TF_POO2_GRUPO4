package Model;

import com.mailjet.client.MailjetClient;
import com.mailjet.client.MailjetRequest;
import com.mailjet.client.MailjetResponse;
import com.mailjet.client.resource.Emailv31;
import org.json.JSONArray;
import org.json.JSONObject;

public class MailSender {

    private static final String API_KEY = "f3a8adb444cbd86975afcc0dc16c0d26";
    private static final String API_SECRET = "17579bde171ee8f08f0f27d092632c2b";
    private static final String FROM_EMAIL = "josecordovafernand3z@gmail.com";
    private static final String FROM_NAME = "SISTEMA DE DENUNCIAS";

    /**
     * Envía un correo usando la API de Mailjet.
     * @param destEmail Email del destinatario
     * @param subject Asunto del mensaje
     * @param mensaje Contenido del mensaje (HTML o texto)
     * @throws Exception Si ocurre un error al enviar
     */
    public static void enviarCorreo(String destEmail, String subject, String mensaje) throws Exception {
        MailjetClient client = new MailjetClient(API_KEY, API_SECRET);

        MailjetRequest request = new MailjetRequest(Emailv31.resource)
                .property(Emailv31.MESSAGES, new JSONArray()
                        .put(new JSONObject()
                                .put(Emailv31.Message.FROM, new JSONObject()
                                        .put("Email", FROM_EMAIL)
                                        .put("Name", FROM_NAME))
                                .put(Emailv31.Message.TO, new JSONArray()
                                        .put(new JSONObject()
                                                .put("Email", destEmail)
                                                .put("Name", "Destinatario")))
                                .put(Emailv31.Message.SUBJECT, subject)
                                .put(Emailv31.Message.TEXTPART, mensaje)
                                .put(Emailv31.Message.HTMLPART, "<h3>" + mensaje + "</h3>")
                        )
                );

        MailjetResponse response = client.post(request);
    }
}