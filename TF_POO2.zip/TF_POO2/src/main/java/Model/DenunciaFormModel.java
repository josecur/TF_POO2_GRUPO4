package Model;

import Util.Denuncia.DetallesDenuncia;
import Util.StringUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DenunciaFormModel {

    public DetallesDenuncia crearDetallesDenuncia(DetallesDenunciaBuilder detalles, String fecha,
                                                  String hora) throws IllegalArgumentException{

        if (fecha == null || fecha.isBlank()) {
            throw new IllegalArgumentException("ERROR: Debe ingresar la fecha");
        }

        if (!isFechaValida(fecha)) {
            throw new IllegalArgumentException("ERROR: La fecha ingresada no es válida");
        }

        if (hora != null && !hora.isBlank() && !isHoraValida(hora)) {
            throw new IllegalArgumentException("ERROR: La hora ingresada no es válida");
        }

        detalles.fechaSuceso(fecha);
        detalles.horaSuceso(StringUtil.nullIfBlank(hora));

        return detalles.build();
    }

    private boolean isFechaValida(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);

        try {
            // Intenta parsear la fecha
            Date parsedDate = sdf.parse(fecha);

            // Extraer día, mes y año para validación de rango
            Calendar cal = Calendar.getInstance();
            cal.setTime(parsedDate);
            int year = cal.get(Calendar.YEAR);

            int currentYear = Calendar.getInstance().get(Calendar.YEAR);
            if (year < 1980 || year > currentYear) {
                return false;
            }

            // Comprobar que no sea una fecha futura
            Date hoy = sdf.parse(sdf.format(new Date()));  // Quita hora/minuto/segundo
            if (parsedDate.after(hoy)) {
                return false;
            }

            return true;
        } catch (ParseException e) {
            // Fecha con formato inválido (ej. 99/99/9999 o letras)
            return false;
        }
    }

    private boolean isHoraValida(String hora) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setLenient(false);
        try {
            Date parsedHora = sdf.parse(hora);
            return sdf.format(parsedHora).equals(hora);
        } catch (ParseException e) {
            return false;
        }
    }


}
