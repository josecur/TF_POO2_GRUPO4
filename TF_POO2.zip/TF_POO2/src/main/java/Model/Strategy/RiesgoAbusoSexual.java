package Model.Strategy;

import Interfaces.NivelRiesgo;
import Interfaces.RiesgoBehavior;
import Util.Denuncia.Denuncia;
import Util.Denuncia.DetallesDenuncia;


public class RiesgoAbusoSexual implements RiesgoBehavior {
    @Override
    public NivelRiesgo evaluarRiesgo(Denuncia denuncia) {
        DetallesDenuncia detalles = denuncia.getDetallesDenuncia();

        if (detalles.isAgresores() || detalles.isHospitalizacion() || detalles.isTestigos()){

            return NivelRiesgo.EXTREMO;
        }

        return NivelRiesgo.CRITICO;
    }
}
