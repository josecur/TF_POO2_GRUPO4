package Model;

import Util.Denuncia.Ubicacion;

public class UbigeoModel {

    public Ubicacion crearUbigeo(String departamento, String provincia, String distrito ,
                                 String direccion, String detalles) throws IllegalArgumentException {

        if(departamento == null || departamento.isEmpty()){
            throw new IllegalArgumentException("Departamento no valido");
        }

        if(distrito == null || distrito.isEmpty()){
            throw new IllegalArgumentException("Distrito no valido");
        }

        if(provincia == null || provincia.isEmpty()){
            throw new IllegalArgumentException("Provincia no valida");
        }

        return new Ubicacion(departamento, provincia, distrito, direccion, detalles);
    }
}
