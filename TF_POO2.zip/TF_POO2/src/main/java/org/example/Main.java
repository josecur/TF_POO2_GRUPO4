package org.example;

import Controller.HomeController;

public class Main {
    public static void main(String[] args) {
        HomeController c = new HomeController();
        c.run();

    }
}